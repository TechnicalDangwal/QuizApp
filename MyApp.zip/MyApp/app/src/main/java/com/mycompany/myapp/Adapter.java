package com.mycompany.myapp;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.content.Context;
import android.view.View;
import java.util.ArrayList;
import android.util.Log;
import com.mycompany.myapp.Models.Categories;
import android.widget.Toast;

public class Adapter extends RecyclerView.Adapter<viewHolder>{
	
	private ArrayList<Categories> list = new ArrayList<Categories>();
	public static Context context;
	
	public Adapter(Context context , ArrayList<Categories> list){
		
		this.list = list;
		this.context = context;
		
	}

	@Override
	public viewHolder onCreateViewHolder(ViewGroup p1, int p2) {
		LayoutInflater inflator = LayoutInflater.from(context);
		View v = inflator.inflate(R.layout.items,p1,false);
		return new viewHolder(v);
	}

	@Override
	public void onBindViewHolder(viewHolder p3, int p2) {
		p3.mtext.setText(list.get(p2).getCategory());
		p3.image.setImageResource(context.getResources().getIdentifier (list.get(p2).getCategory().toLowerCase(),"drawable",context.getPackageName()));
		}

	@Override
	public int getItemCount() {
		return list.size();
	}

    
}
