package com.mycompany.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.os.AsyncTask;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import android.widget.TextView;
import android.widget.RadioButton;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.view.View;
import org.json.JSONException;
import com.mycompany.myapp.Models.questions;
import java.util.ArrayList;

public class quiz extends AppCompatActivity implements View.OnClickListener {


	private TextView q , s;
	private RadioGroup rg;
	private RadioButton op1 , op2 , op3 , op4;
	private Button btn;
	public static int index = 0;
	private int score = 0;
	public static ArrayList<questions> data = new ArrayList<questions>();
    task a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz);


		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);

		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		getSupportActionBar().setTitle("Quiz App");
		getSupportActionBar().setSubtitle(getIntent().getStringExtra("category"));

		q = findViewById(R.id.question);
		s = findViewById(R.id.score);
		op1 = findViewById(R.id.option1);
		op2 = findViewById(R.id.option2);
		op3 = findViewById(R.id.option3);
		op4 = findViewById(R.id.option4);
		rg = findViewById(R.id.quizRadioGroup);
		btn = findViewById(R.id.quizButton1);

		if (savedInstanceState != null) {
			index = savedInstanceState.getInt("Index");
			score = savedInstanceState.getInt("Score");

			s.setText(String.valueOf(score));
		}

		a = new task();
		a.execute("http://0.0.0.0:8080/a.php?category=" + getIntent().getStringExtra("category").toLowerCase());
		btn.setOnClickListener(this);

		//Log.i("Tag",data.get(0).getQuestion());
	}

	@Override
	public void onClick(View p1) {
		switch (rg.getCheckedRadioButtonId()) {
			case R.id.option1:
				if (data.get(index).getResult().equalsIgnoreCase(op1.getText().toString())) {
					Toast.makeText(quiz.this, "Right Answer", Toast.LENGTH_SHORT).show();
					score++;
					index++;
					update();
					op1.setChecked(false);
					s.setText(String.valueOf(score));


				} else {
					Toast.makeText(quiz.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
					update();
				}
				Log.i("Tag", op1.getText().toString() + data.size());
				Log.i("Tag" , index + " index ");
				break;
			case R.id.option2:
				if (data.get(index).getResult().equalsIgnoreCase(op2.getText().toString())) {
					Toast.makeText(quiz.this, "Right Answer", Toast.LENGTH_SHORT).show();
					score++;
					index++;
					update();
					op1.setChecked(false);
					s.setText(String.valueOf(score));

				} else {
					Toast.makeText(quiz.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
					update();
				}
				break;
			case R.id.option3:
				if (data.get(index).getResult().equalsIgnoreCase(op3.getText().toString())) {
					Toast.makeText(quiz.this, "Right Answer", Toast.LENGTH_SHORT).show();
					score++;
					index++;
					update();
					op1.setChecked(false);
					s.setText(String.valueOf(score));


				} else {
					Toast.makeText(quiz.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
					update();
				}
				break;
			case R.id.option4:
				if (data.get(index).getResult().equalsIgnoreCase(op4.getText().toString())) {
					Toast.makeText(quiz.this, "Right Answer", Toast.LENGTH_SHORT).show();
					score++;
					index++;
					update();
					op1.setChecked(false);
					s.setText(String.valueOf(score));


				} else {
					Toast.makeText(quiz.this, "Wrong Answer", Toast.LENGTH_SHORT).show();
					update();
				}
				break;
			default:
				Toast.makeText(quiz.this, "You don't skip questions", Toast.LENGTH_SHORT).show();
		}

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		outState.putInt("Index", index);
		outState.putInt("Score", score);
		super.onSaveInstanceState(outState);
	}




	public void update() {

		if (index < data.size()) {
			q.setText(data.get(index).getQNo() + data.get(index).getQuestion());
			op1.setText(data.get(index).getOp1());
			op2.setText(data.get(index).getOp2());
			op3.setText(data.get(index).getOp3());
			op4.setText(data.get(index).getOp4());
			Log.i("Tag" , index + " index ");

		} else {
			index = 0;
			score = 0;
		}

	}


	class task extends AsyncTask<String, Void , String> {



		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			try {
				Log.i("Tag", "" + result);
				JSONArray ja = new JSONArray(result);
				Log.i("Tag", "" + ja);
				for (int i = 0 ; i < ja.length() ; i ++) {
					questions a = new questions();
					JSONObject jo = ja.getJSONObject(i);
					//JSONObject j= new JSONObject(ja.toString());
					a.setQNo(Integer.valueOf(jo.getString("qNo")));
					a.setQuestion(jo.getString("Question"));
					a.setOp1(jo.getString("Option 1"));
					a.setOp2(jo.getString("Option 2"));
					a.setOp3(jo.getString("Option 3"));
					a.setOp4(jo.getString("Option 4"));
					a.setResult(jo.getString("Result"));
					data.add(a);
					//Log.i("Tag",i+a.getQuestion());
				}
				
				update();
				//data.add();

			} catch (Exception e) {
				Log.i("Tag", "Error" + e.toString());
				q.setVisibility(View.GONE);
				s.setVisibility(View.GONE);
				rg.setVisibility(View.GONE);
				btn.setVisibility(View.GONE);
				Toast.makeText(quiz.this, "Sorry There Is No Quiz In " + getIntent().getStringExtra("category") + " Category", Toast.LENGTH_SHORT).show();
			}
		}



		@Override
		protected String doInBackground(String[] p1) {
			try {
				URL url = new URL(p1[0]);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuffer data = new StringBuffer();
				String line;

				while ((line = br.readLine()) != null) {
					data.append(line + "\n");
				}

				br.close();
				Log.i("Tag" , data.toString());
				//Log.i("Tag" , String.valueOf(br.readLine().length()));

				return data.toString();
			} catch ( Exception e) {
				return e.toString();
			}
		}


	}



}
