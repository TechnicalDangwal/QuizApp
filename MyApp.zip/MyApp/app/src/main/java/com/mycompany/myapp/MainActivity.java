package com.mycompany.myapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.Button;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import java.util.ArrayList;
import android.util.Log;
import com.mycompany.myapp.Models.Categories;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.GridLayoutManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
	
	private TabLayout tablayout;
	private ViewPager viewPager;
	private RecyclerView recyclerView;
	private ArrayList<Categories> list = new ArrayList<Categories>();
	private String[] n = {"CyberSecurity" , "Python" , "C" , "Java" , "Networking" , "PHP"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		
		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		
		getSupportActionBar().setTitle("Quiz App");
		getSupportActionBar().setSubtitle("Categories");
		
	
		
		
		recyclerView = findViewById(R.id.recyclerView);
		
		for(int i = 0 ; i < n.length ; i++){
			Categories category = new Categories();
			category.setCategory(n[i]);
			String a = "R.drawable."+n[i].toLowerCase();
			category.setImageUrl(a);
			list.add(category);
		}
		
		
		
		
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		Adapter adapter = new Adapter(this,list);
		recyclerView.setAdapter(adapter);
		
		
		
		//getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		/*Button btn = findViewById(R.id.btn);
		btn.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					//Intent i = new Intent(MainActivity.this,a.class);
					//startActivity(i)
				}
			});*/
			


	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		new MenuInflater(this).inflate(R.menu.opt,menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if(item.getItemId() == R.id.item){
			startActivity(new Intent(this,login.class));
		}
		return super.onOptionsItemSelected(item);
	}

	
	
}
