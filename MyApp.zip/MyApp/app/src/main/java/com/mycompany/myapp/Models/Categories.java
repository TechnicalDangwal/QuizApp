package com.mycompany.myapp.Models;
import android.content.res.Resources;

public class Categories {
	
	private String category , imageUrl;

	
	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl =  imageUrl;
	}

	public String getImageUrl() {
		return imageUrl;
	}
    
}
