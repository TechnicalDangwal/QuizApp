package com.mycompany.myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.EditText;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.os.AsyncTask;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class login extends AppCompatActivity {
    EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		Toolbar toolbar = findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		getSupportActionBar().setTitle("Quiz");
		getSupportActionBar().setSubtitle("Login");
		
		
		Button login;
		
		username = findViewById(R.id.loginEditText1);
		password = findViewById(R.id.loginEditText2);
		login = findViewById(R.id.loginButton1);
		login.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					task a = new task();
					a.execute("http://0.0.0.0:8080/login.php?username="+username.getText().toString()+"&&password="+password.getText().toString());
				}
				
			
		});
		
    }
    class task extends AsyncTask<String, Void , String> {



		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			try {
				if(result.isEmpty() == false)
				{
					Toast.makeText(login.this,"Login",Toast.LENGTH_SHORT).show();
				Log.i("Tag", "" + result);
				
				}
				else{
				Log.i("Tag", "error" +  result);
				}
				//data.add();

			} catch (Exception e) {
				Log.i("Tag", "Error" + e.toString());

				Toast.makeText(login.this, "Sorry There Is No Quiz In " ,Toast.LENGTH_SHORT).show();
			}
		}



		@Override
		protected String doInBackground(String[] p1) {
			try {
				URL url = new URL(p1[0]);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuffer data = new StringBuffer();
				String line;

				while ((line = br.readLine()) != null) {
					data.append(line + "\n");
				}

				br.close();
				
				//Log.i("Tag" , String.valueOf(br.readLine().length()));

				return data.toString();
			} catch ( Exception e) {
				Log.i("Tag" ,"errorz"+ e.toString());
				return e.toString();
			}
		}


	}
}
