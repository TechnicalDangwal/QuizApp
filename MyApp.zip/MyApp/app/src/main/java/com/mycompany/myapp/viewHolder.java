package com.mycompany.myapp;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.Intent;

public class viewHolder extends RecyclerView.ViewHolder{
	
	public ImageView image;
	public TextView mtext;
	viewHolder(View v){
		super(v);
		mtext = itemView.findViewById(R.id.itemsTextView);
		image = itemView.findViewById(R.id.itemsTextView1);
		Log.i("Tag","inside3");
		itemView.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					Intent intent = new Intent(Adapter.context,quiz.class);
					intent.putExtra("category",mtext.getText().toString());
					Adapter.context.startActivity(intent);
				}

			
		});
	}
    
}
